import pandas as pd
from matplotlib import pyplot as plt
import numpy as np
from log_regression import log_regression
from NaiveBayes import NaiveBayes
from cross_validation import cross_validation
import separate
import time

# ionosphere data

data = pd.read_csv("iono.csv", header=None)

# Transform data and targets in numpy arrays
#data = data.as_matrix()
data = data.values
res = np.zeros(len(data))

# Transform targets in a binary representation
for i in range(len(data)):
    if data[i][len(data[0])-1] == 'g':
        res[i]=1
    elif data[i][len(data[0])-1] == 'b':
        res[i]=0

# delete target from data (last column from data)
data = np.delete(data, len(data[0])-1, 1)

#print(data)

# Detect oddities
for i in range(len(data)):
    # Test for missing data
    if len(data[0]) != len(data[i]):
        print("values on row ",i, " are missing")
    
    # Test for malformed features (non-float or integer)
    for j in range(len(data[0])):
        if not(isinstance(data[i][j], int) or isinstance(data[i][j], float)):
            print("value at coordinates",(i,j), "is malformed")

# Histogram of the targets
plt.figure(1)
#plt.hist(res) 
plt.hist([res[np.argwhere(res == 0)], res[np.argwhere(res == 1)]], label=['bad', 'good'])
plt.legend(loc='upper right') 
plt.title("Distribution of the positive vs negative classes") 
plt.show()

# Distributions of some numerical features (feature columns 2,3,4,5 were considered)
pos = np.argwhere(res == 1)
neg = np.argwhere(res == 0)

# matrices (feature, data point) - separation between positive and negative features
pos_features = np.zeros((4,len(pos))) 
neg_features = np.zeros((4,len(neg)))
for i in range(4):
    neg_features[i,:] = np.squeeze(data[neg, i+2])
    pos_features[i,:] = np.squeeze(data[pos, i+2])


plt.figure(2)

for i in range(4):
    plt.subplot(2,2,i+1)
    
    # Set bin boundaries by the minimum and maximum values of the features
    bins = np.linspace(min(min(neg_features[i,:]), min(pos_features[i,:])),
                       max(max(neg_features[i,:]), max(pos_features[i,:])), 30)
    
    # Plot the histogram of the positive and negative features
    plt.hist([neg_features[i,:], pos_features[i,:]], bins, label=['neg', 'pos'])
    plt.legend(loc='upper right')    
    
    plt.title("Distribution of feature #" + str(i+2))

plt.show()


# Correlation between some numerical features (feature columns 2,3,4,5 were considered)

plt.figure(3)

for i in range(4):
    plt.subplot(2,2,i+1)
    
    # Correlation coefficients
    r_neg = np.corrcoef(neg_features[i,:], neg_features[(i+1)%4,:])
    r_pos = np.corrcoef(pos_features[i,:], pos_features[(i+1)%4,:])
    
    # Labels for the legend
    lbl_neg = "r_neg = " + str(round(r_neg[0,1],4))
    lbl_pos = "r_pos = " + str(round(r_pos[0,1],4))
    
    plt.scatter(neg_features[i,:], neg_features[(i+1)%4,:], label=lbl_neg)
    plt.scatter(pos_features[i,:], pos_features[(i+1)%4,:], label=lbl_pos)
    
    plt.legend(loc='upper right')    
    
    plt.title("Correlation between feature #" + str(i+2) + " and #" + str(((i+1)%4)+2))    
    
plt.show()



# Final data variables X and target variables Y
X = np.array(data)
Y = np.array(res)



## Compare accuracy of naive Bayes and logistic regression before finding best learning rate

# All datasets will use for logistic regression the same learning rate = 0.01 and # iterations = 10000
rate = 0.01
iterations = 10000

log_model  = log_regression(rate, iterations)
X = log_model.bias(X) # add bias column

# Separate training and testing sets 
X_train, Y_train, X_test, Y_test = separate.separate(X,Y)


## Logistic regression

t1 = time.time()
# Cross validation
validation  = cross_validation(rate, max_iterations = iterations)
score = validation.evaluate_log(X_train,Y_train)
t2 = time.time()
print("Averaged training accuracy for Logistic Regression is ", score, "and took ", (t2-t1), " seconds.")

# train the data
t1 = time.time()
log_model  = log_regression(rate, iterations)
fit_iono  = log_model.fit(X_train,Y_train) 

# Test data
pre = log_model.predict(X_test,fit_iono) 
acc = log_model.evaluate_acc(pre,Y_test)
t2 = time.time()
print("Accuracy on testing data for Logistic Regression is ", acc, "and took ", (t2-t1), " seconds.")

## Naive Bayes



# Cross validation
t1 = time.time()
bayes_model = NaiveBayes()
score = bayes_model.cross_validation(X_train,Y_train)
t2 = time.time()
print("Averaged training accuracy for Naive Bayes is ", score, "and took ", (t2-t1), " seconds.")


# Test data
t1 = time.time()
bayes_model = NaiveBayes()
fit_bayes = bayes_model.fit(X_train,Y_train)
pre = bayes_model.predict(X_test)
acc = bayes_model.evaluate_acc(pre,Y_test)
t2 = time.time()
print("Accuracy on testing data for Naive Bayes is ", acc, "and took ", (t2-t1), " seconds.")

print()
## Test different learning rates for gradient descent

# Loss function threshold = 5*10^-5; maximum number of iterations = 1000

# Find automatically the best rate by choosing the rate that gives the best
# validation accuracy with the lowest number of iterations
best_rate = 0
best_accuracy = 0
lowest_iterations = 0

acc = []
iters = []
rates = []
rate = 10**-15
for i in range(20):
    
    # Cross validation
    validation  = cross_validation(rate, threshold = True)
    score, iterations = validation.evaluate_log(X_train,Y_train)
    #print("Averaged training accuracy for Logistic Regression: ", score)
    print("rate = ", rate, "; iterations = ", iterations, "; accuracy = ", score)
    iters.append(iterations)
    acc.append(score)
    
    if best_accuracy < score:
        best_accuracy = score
        best_rate = rate
        lowest_iterations = iterations
        
    elif best_accuracy == score and lowest_iterations > iterations:
        best_accuracy = score
        best_rate = rate
        lowest_iterations = iterations     
    
    rates.append(rate)
    
    rate *= 10
    
    
    
plt.figure(4)
plt.scatter(iters, acc)
plt.xlabel("iterations")
plt.ylabel("accurary")
plt.title("the accuracy on train set as a function of iterations of gradient descent")

plt.figure(8)
plt.plot(rates, acc)
plt.xlabel("rate")
plt.xscale('log')
plt.xlim((10**-15, 10**4))
plt.ylabel("accurary")
plt.title("the accuracy on train set as a function of the learning rate of gradient descent")

plt.show()

print()
print("The best learning rate found is: ", best_rate)
print()


## Compare accuracy of naive Bayes and logistic regression before finding best learning rate

rate = best_rate
iterations = 10000

## Logistic regression

t1 = time.time()
# Cross validation
validation  = cross_validation(rate, max_iterations = iterations)
score = validation.evaluate_log(X_train,Y_train)
t2 = time.time()
print("Averaged training accuracy for Logistic Regression is ", score, "and took ", (t2-t1), " seconds.")

# train the data
t1 = time.time()
log_model  = log_regression(rate, iterations)
fit_iono  = log_model.fit(X_train,Y_train) 

# Test data
pre = log_model.predict(X_test,fit_iono) 
acc = log_model.evaluate_acc(pre,Y_test)
t2 = time.time()
print("Accuracy on testing data for Logistic Regression is ", acc, "and took ", (t2-t1), " seconds.")

## Naive Bayes



# Cross validation
t1 = time.time()
bayes_model = NaiveBayes()
score = bayes_model.cross_validation(X_train,Y_train)
t2 = time.time()
print("Averaged training accuracy for Naive Bayes is ", score, "and took ", (t2-t1), " seconds.")


# Test data
t1 = time.time()
bayes_model = NaiveBayes()
fit_bayes = bayes_model.fit(X_train,Y_train)
pre = bayes_model.predict(X_test)
acc = bayes_model.evaluate_acc(pre,Y_test)
t2 = time.time()
print("Accuracy on testing data for Naive Bayes is ", acc, "and took ", (t2-t1), " seconds.")

print()







## Accuracy as a function of the size of dataset

# Logistic regression
acc = []
size = []
accT = []
sizeT = []
split_size = 0.1

for i in range(9):
    X_train_size, Y_train_size, X_discard, Y_discard = separate.separate(X_train,Y_train, split=split_size)
    # Cross validation
    validation  = cross_validation(rate, threshold = True)
    score, iterations = validation.evaluate_log(X_train_size,Y_train_size)
    #print("Averaged training accuracy for Logistic Regression: ", score)
    print("CV: size of X = ", X_train_size.shape[0], "; iterations = ", iterations, "; accuracy = ", score)
    
    # Test data
    log_model = log_regression(rate, 500)
    fit_iono  = log_model.fit(X_train_size,Y_train_size)
    pre = log_model.predict(X_test,fit_iono) 
    accur = log_model.evaluate_acc(pre,Y_test)
    print("Test: size of X = ", X_train_size.shape[0], "; accuracy = ", accur)
    #print("Accuracy on testing data for Logistic Regression: ", acc)    
    
    
    size.append(X_train_size.shape[0])
    acc.append(score)
    
    sizeT.append(X_train_size.shape[0])
    accT.append(accur)    
    
    split_size += 0.1

split_size = 0.91
for i in range(8):
    X_train_size, Y_train_size, X_discard, Y_discard = separate.separate(X_train,Y_train, split=split_size)
    # Cross validation
    validation  = cross_validation(rate, threshold = True)
    score, iterations = validation.evaluate_log(X_train_size,Y_train_size)
    #print("Averaged training accuracy for Logistic Regression: ", score)
    print("CV: size of X = ", X_train_size.shape[0], "; iterations = ", iterations, "; accuracy = ", score)
    
    # Test data
    log_model = log_regression(rate, 500)
    fit_iono  = log_model.fit(X_train_size,Y_train_size)
    pre = log_model.predict(X_test,fit_iono) 
    accur = log_model.evaluate_acc(pre,Y_test)
    print("Test: size of X = ", X_train_size.shape[0], "; accuracy = ", accur)
    #print("Accuracy on testing data for Logistic Regression: ", acc)    
    
    
    size.append(X_train_size.shape[0])
    acc.append(score)
    
    sizeT.append(X_train_size.shape[0])
    accT.append(accur)    
    
    split_size += 0.01

log_sizeT = sizeT
log_accT = accT

plt.figure(5)    
plt.plot(size, acc, label = "CV")
plt.plot(sizeT, accT, label = "Test")
plt.legend()
plt.xlabel("size of X_train")
plt.ylabel("accurary")
plt.title("the accuracy on train set as a function of size of X on logistic model")

plt.show()

print()

#bayes model
acc = []
size = []
accT = []
sizeT = []
split_size = 0.1

for i in range(9):
    X_train_size, Y_train_size, X_discard, Y_discard = separate.separate(X_train,Y_train, split=split_size)
    # Cross validation
    bayes_model = NaiveBayes()
    score = bayes_model.cross_validation(X_train_size,Y_train_size)
    print("CV: size of X = ", X_train.shape[0], "; accuracy = ", score)
    
    # Test data
    bayes_model = NaiveBayes()
    fit_bayes = bayes_model.fit(X_train_size,Y_train_size)
    pre = bayes_model.predict(X_test)
    accur = bayes_model.evaluate_acc(pre,Y_test)
    print("Test: size of X = ", X_train_size.shape[0], "; accuracy = ", accur)
    #print("Accuracy on testing data for Logistic Regression: ", acc)    
    
    
    size.append(X_train_size.shape[0])
    acc.append(score)
    
    sizeT.append(X_train_size.shape[0])
    accT.append(accur)    
    
    split_size += 0.1

split_size = 0.91
for i in range(8):
    X_train_size, Y_train_size, X_discard, Y_discard = separate.separate(X_train,Y_train, split=split_size)
    # Cross validation
    bayes_model = NaiveBayes()
    score = bayes_model.cross_validation(X_train_size,Y_train_size)
    print("CV: size of X = ", X_train.shape[0], "; accuracy = ", score)
    
    # Test data
    bayes_model = NaiveBayes()
    fit_bayes = bayes_model.fit(X_train_size,Y_train_size)
    pre = bayes_model.predict(X_test)
    accur = bayes_model.evaluate_acc(pre,Y_test)
    print("Test: size of X = ", X_train_size.shape[0], "; accuracy = ", accur)
    #print("Accuracy on testing data for Logistic Regression: ", acc)    
    
    
    size.append(X_train_size.shape[0])
    acc.append(score)
    
    sizeT.append(X_train_size.shape[0])
    accT.append(accur)    
    
    split_size += 0.01


#for i in range(9):
    #X_train, Y_train, X_test, Y_test = separate.separate(X,Y, split=split_size)
    ## Cross validation
    #score = bayes_model.cross_validation(X_train,Y_train)
    ##print("Averaged training accuracy for Logistic Regression: ", score)
    #print("size of X = ", X_train.shape[0], "; accuracy = ", score)
    #size.append(X_train.shape[0])
    #acc.append(score)
    #split_size += 0.1

plt.figure(6)    
plt.xlabel("size of X_train")
plt.ylabel("accurary")
plt.title("the accuracy on train set as a function of size od X on Naive Bayes model")
plt.plot(size, acc, label = "CV")
plt.plot(sizeT, accT, label = "Test")
plt.legend()
plt.show()

plt.figure(7)    
plt.xlabel("size of X_train")
plt.ylabel("accurary")
plt.title("the accuracy on train set as a function of size od X on Naive Bayes model")
plt.plot(log_sizeT, log_accT, label = "Logistic Regression Test")
plt.plot(sizeT, accT, label = "Naive Bayes Test")
plt.legend()
plt.show()